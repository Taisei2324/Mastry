MASTRY 3D BOTTLE — drop-in embed
================================

Files:
  bottle-3d.js       the web component
  assets/label.jpg   label texture
  assets/cap.obj     max-LOD aluminum cap (loaded at runtime)

Embed (in index.html):

  <script src="https://unpkg.com/three@0.147.0/build/three.min.js"></script>
  <script src="bottle-3d.js"></script>
  <bottle-3d label-src="assets/label.jpg" cap-src="assets/cap.obj"
    condensation="2" spin-speed="1" offset-x="1.55"
    style="position:fixed;inset:0;z-index:5;pointer-events:none"></bottle-3d>

Attributes:
  offset-x       horizontal position in scene units (0 = centered, 1.55 = right of hero text)
  condensation   0-10 droplet density (0 = off)
  spin-speed     idle rotation multiplier
  pour           "0" disables the end-of-scroll cap-off + pour finale
  label-src / cap-src   asset paths relative to the page

Push to a new branch:
  git checkout -b bottle-3d
  git add bottle-3d.js assets/
  git commit -m "Add 3D scroll-reactive bottle"
  git push -u origin bottle-3d
