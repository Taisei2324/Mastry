SOFTENED / NO TOP RING VERSION
==============================
Changes:
- removed the unnecessary ring/crown from the top of the stopper
- increased stopper corner radius
- softened stopper top and bottom bevels
- reduced hard 90-degree transitions
- rounded side walls and shoulder flow
- kept the physical V-cut grooves
- separate stopper remains beside the bottle
